
# Image Recognition and Classification Project

This project aims to develop a convolutional neural network (CNN) to classify images. The project involves data collection, preprocessing, model building using TensorFlow/Keras, and evaluation.

## Tools Used
- Python
- TensorFlow/Keras
- OpenCV
- Jupyter Notebook

## Project Structure
- `data/`: Contains the dataset.
- `image_recognition.ipynb`: Jupyter Notebook with the project code and documentation.

## How to Run
1. Clone the repository.
2. Install the required packages: `pip install -r requirements.txt`
3. Open `image_recognition.ipynb` in Jupyter Notebook.
4. Run the cells sequentially.

## Results
The image recognition model was successfully implemented and evaluated.
